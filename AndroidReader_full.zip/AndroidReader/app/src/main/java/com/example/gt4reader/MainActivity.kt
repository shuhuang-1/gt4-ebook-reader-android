package com.example.gt4reader

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var btnPick: Button
    private lateinit var btnPush: Button
    private lateinit var tvInfo: TextView
    private lateinit var tvProgress: TextView
    private lateinit var rvChapters: RecyclerView

    private var currentBook: BookParser.Book? = null

    // ★ 权限批下来后，把这里换成 WearEngineTransport(this)
    private val transport: Transport = MockTransport()
    private lateinit var pusher: Pusher

    private val pickFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri ?: return@registerForActivityResult
            runCatching {
                contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            loadBook(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPick = findViewById(R.id.btnPick)
        btnPush = findViewById(R.id.btnPush)
        tvInfo = findViewById(R.id.tvInfo)
        tvProgress = findViewById(R.id.tvProgress)
        rvChapters = findViewById(R.id.rvChapters)
        rvChapters.layoutManager = LinearLayoutManager(this)

        pusher = Pusher(transport)

        btnPick.setOnClickListener {
            pickFile.launch(arrayOf("text/plain", "text/*", "*/*"))
        }
        btnPush.setOnClickListener { startPush() }

        tvProgress.text = transport.statusText()
    }

    private fun loadBook(uri: Uri) {
        tvInfo.text = "解析中…"
        thread {
            try {
                val tmp = java.io.File(cacheDir, "book.tmp")
                contentResolver.openInputStream(uri)?.use { input ->
                    tmp.outputStream().use { out -> input.copyTo(out) }
                }
                val book = BookParser.parse(tmp)

                // 先算一下要切多少片，让用户有个预期
                val id = Proto.bookId(book.name)
                val chunks = Splitter.buildChunks(id, book)

                runOnUiThread {
                    currentBook = book
                    tvInfo.text = "《${book.name}》 ${book.chapters.size} 章 → ${chunks.size} 片\n" +
                            "编码 ${book.encoding}　id ${id}"
                    rvChapters.adapter = ChapterAdapter(book.chapters)
                    btnPush.isEnabled = chunks.isNotEmpty()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tvInfo.text = "解析失败：${e.message}"
                }
            }
        }
    }

    private fun startPush() {
        val book = currentBook ?: return
        btnPush.isEnabled = false
        btnPick.isEnabled = false

        pusher.push(
            book = book,
            onProgress = { sent, total ->
                tvProgress.text = "推送中 $sent/$total"
            },
            onDone = { ok, msg ->
                tvProgress.text = msg
                btnPush.isEnabled = true
                btnPick.isEnabled = true
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            }
        )
    }
}

class ChapterAdapter(private val chapters: List<BookParser.Chapter>) :
    RecyclerView.Adapter<ChapterAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(android.R.id.text1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_1, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.title.text = chapters[position].title
    }

    override fun getItemCount(): Int = chapters.size
}
